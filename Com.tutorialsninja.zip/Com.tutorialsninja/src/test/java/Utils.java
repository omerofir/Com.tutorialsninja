public class Utils {
    final static String BASE_URL = "http://tutorialsninja.com/demo/index.php";
    final static String CHROME_DRIVER_LOCATION = "d:\\Com.tutorialsninja\\chromedriver.exe";
}
